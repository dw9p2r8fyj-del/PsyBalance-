const KEY="psyBalanceDataV1";
const defaults={
  name:"Аружан", onboarded:false, moodLogs:[], diary:[], tests:[], language:"Қазақша"
};
let state=JSON.parse(localStorage.getItem(KEY)||"null")||defaults;
let current="home";

const moods=[
 {id:"happy",e:"😊",name:"Жақсы",v:5},{id:"calm",e:"😌",name:"Қалыпты",v:4},
 {id:"neutral",e:"😐",name:"Бейтарап",v:3},{id:"sad",e:"😔",name:"Көңілсіз",v:2},
 {id:"angry",e:"😟",name:"Мазасыз",v:1}
];

function save(){localStorage.setItem(KEY,JSON.stringify(state))}
function esc(s){return String(s||"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
function toast(t){const x=document.createElement("div");x.className="toast";x.textContent=t;document.body.appendChild(x);setTimeout(()=>x.remove(),2400)}
function today(){return new Date().toLocaleDateString("kk-KZ",{day:"numeric",month:"long",year:"numeric"})}
function dateKey(d=new Date()){return d.toISOString().slice(0,10)}

function shell(content){
return `<div class="app-shell">
<header class="topbar">
 <div class="brand"><div class="logo">◒</div><span>PsyBalance</span></div>
 <div class="top-actions"><button class="icon-btn" onclick="showSettings()" aria-label="Баптаулар">⚙</button></div>
</header>
<main class="main">${content}</main>
<nav class="nav">
 ${nav("home","⌂","Басты бет")}${nav("stats","▥","Статистика")}${nav("diary","▤","Күнделік")}${nav("tests","✓","Тесттер")}${nav("more","•••","Көбірек")}
</nav>
</div>`}
function nav(id,icon,label){return `<button class="${current===id?'active':''}" onclick="go('${id}')"><span class="nav-icon">${icon}</span>${label}</button>`}

function render(){
 if(!state.onboarded){renderOnboard();return}
 let body="";
 if(current==="home") body=home();
 if(current==="stats") body=stats();
 if(current==="diary") body=diary();
 if(current==="tests") body=tests();
 if(current==="more") body=more();
 document.getElementById("app").innerHTML=shell(body);
}
function renderOnboard(){
 document.getElementById("app").innerHTML=`<div class="onboard"><div class="onboard-card">
 <div class="onboard-art">🌿</div><div class="eyebrow">Эмоционалдық әл-ауқат</div>
 <h1>PsyBalance</h1><p class="muted">Ішкі тыныштық — өзіңнен басталады</p>
 <p>Күнделікті көңіл-күйді бақылаңыз, ойларыңызды жазып, стресс деңгейін бағалап, өзіңізге пайдалы әдеттерді қалыптастырыңыз.</p>
 <div class="field" style="text-align:left"><label>Атыңыз</label><input id="oname" placeholder="Мысалы: Аружан" value="${esc(state.name)}"></div>
 <button class="btn" style="width:100%;margin-top:8px" onclick="startApp()">Бастау</button>
 <p class="small muted" style="margin-top:15px">Деректеріңіз осы құрылғыда сақталады.</p>
 </div></div>`
}
function startApp(){state.name=(document.getElementById("oname").value||"Аружан").trim();state.onboarded=true;save();render()}

function home(){
 const last=state.diary[0];
 return `<section class="grid grid-2">
 <div class="card hero">
   <div style="position:relative;z-index:1"><div class="eyebrow">Бүгінгі көңіл-күй</div>
   <h1>Сәлем, ${esc(state.name)}!</h1><p class="muted">Бүгінгі көңіл-күйіңізді белгілеңіз</p>
   <div class="mood-row">${moods.map(m=>`<button class="mood" onclick="logMood('${m.id}')"><span class="emoji">${m.e}</span><span class="small">${m.name}</span></button>`).join("")}</div></div>
 </div>
 <div class="card tip"><div class="eyebrow">Бүгін өзіңізге</div><h2>Кішкентай қадам — үлкен өзгеріс</h2><p class="muted">2 минут терең тыныс алып, қазіргі сәтке назар аударып көріңіз.</p><button class="btn secondary" onclick="breathing()">Тыныс алу жаттығуы</button></div>
 </section>
 <section style="margin-top:18px" class="grid grid-3">
  <div class="card"><div class="eyebrow">Соңғы жазба</div>${last?`<h3 style="margin-top:10px">${esc(last.text).slice(0,100)}</h3><p class="small muted">${esc(last.date)}</p>`:`<div class="empty">Күнделік әзірге бос.</div>`}</div>
  <div class="card"><div class="eyebrow">Апталық көңіл-күй</div><div class="stat"><span>Орташа көрсеткіш</span><b>${avgMood()}</b></div><div class="progress"><span style="width:${avgMood()*20}%"></span></div></div>
  <div class="card"><div class="eyebrow">Жылдам тест</div><h3>Стресс деңгейін бағалау</h3><p class="small muted">5 қысқа сұрақ · шамамен 2 минут</p><button class="btn secondary" onclick="go('tests')">Тестке өту</button></div>
 </section>
 <section style="margin-top:18px" class="card"><div class="quote">«Өзіңізге қамқор болу — әлсіздік емес, бұл күш.»</div><p class="muted">PsyBalance</p></section>`
}
function logMood(id){
 const m=moods.find(x=>x.id===id); state.moodLogs.unshift({date:dateKey(),label:m.name,value:m.v,emoji:m.e});state.moodLogs=state.moodLogs.slice(0,90);save();toast(`${m.e} Көңіл-күйіңіз сақталды`);render()
}
function avgMood(){
 if(!state.moodLogs.length)return "—";
 return (state.moodLogs.slice(0,7).reduce((a,b)=>a+b.value,0)/Math.min(7,state.moodLogs.length)).toFixed(1)
}

function stats(){
 const recent=state.moodLogs.slice(0,7).reverse();
 const values=recent.length?recent.map(x=>x.value):[2,3,4,3,4,5,4];
 const max=Math.max(...values,5);
 const stress=state.tests.find(t=>t.type==="stress");
 return `<div class="row between"><div><div class="eyebrow">Статистика</div><h1>Өз динамикаңыз</h1><p class="muted">Соңғы көңіл-күй белгілеріңізге шолу.</p></div><button class="btn ghost" onclick="clearLogs()">Тазалау</button></div>
 <section class="grid grid-2" style="margin-top:18px">
 <div class="card"><h2>Көңіл-күй динамикасы</h2><div class="chart">${values.map((v,i)=>`<div class="bar-wrap"><div class="bar" style="height:${v/max*78}%"></div><span class="bar-label">${i+1}</span></div>`).join("")}</div><p class="small muted">1 — өте төмен · 5 — өте жақсы</p></div>
 <div class="card"><h2>Стресс деңгейі</h2><div style="display:grid;place-items:center;padding:12px"><div style="width:150px;height:150px;border-radius:50%;background:conic-gradient(var(--green) ${stress?Math.min(stress.score*10,100):32}%,#edf1ef 0);display:grid;place-items:center"><div style="width:110px;height:110px;background:#fff;border-radius:50%;display:grid;place-items:center;text-align:center"><b style="font-size:28px">${stress?stress.score*10:32}%</b><span class="small muted">${stress?"Бағаланған":"Үлгі"}</span></div></div></div><p class="muted small">Бұл көрсеткіш диагноз емес, өзін-өзі бақылауға арналған.</p></div>
 </section>
 <section class="card" style="margin-top:18px"><h2>Жиі кездесетін эмоциялар</h2>${emotionBars()}</section>`
}
function emotionBars(){
 if(!state.moodLogs.length)return `<div class="empty">Көңіл-күй белгілеген сайын статистика осында пайда болады.</div>`;
 const counts={};state.moodLogs.forEach(x=>counts[x.label]=(counts[x.label]||0)+1);
 const total=state.moodLogs.length;
 return Object.entries(counts).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`<div class="stat"><span>${k}</span><span style="min-width:55%;display:flex;align-items:center;gap:10px"><div class="progress" style="flex:1"><span style="width:${v/total*100}%"></span></div><b>${Math.round(v/total*100)}%</b></span></div>`).join("")
}
function clearLogs(){if(confirm("Көңіл-күй тарихын тазалау керек пе?")){state.moodLogs=[];save();render()}}

function diary(){
 return `<div class="row between"><div><div class="eyebrow">Күнделік</div><h1>Ойларыңызды жазыңыз</h1><p class="muted">Сезімдеріңізді қағазға түсіргендей еркін жазыңыз.</p></div><button class="btn" onclick="newDiary()">＋ Жазба</button></div>
 <section class="card" style="margin-top:18px">${state.diary.length?state.diary.map(d=>`<article class="diary-item"><div class="row between"><b>${esc(d.mood||"Күнделік")}</b><span class="small muted">${esc(d.date)}</span></div><p>${esc(d.text)}</p></article>`).join(""):`<div class="empty"><div style="font-size:44px">📖</div><h3>Алғашқы жазбаңызды бастаңыз</h3><p>Бүгін не сезіндіңіз? Не нәрсе қуантты немесе алаңдатты?</p><button class="btn" onclick="newDiary()">Жазу</button></div>`}</section>`
}
function newDiary(){
 document.body.insertAdjacentHTML("beforeend",`<div class="modal-back" id="modal"><div class="modal"><div class="row between"><h2>Жаңа жазба</h2><button class="icon-btn" onclick="closeModal()">×</button></div>
 <div class="field"><label>Бүгінгі көңіл-күй</label><select id="dmood">${moods.map(m=>`<option>${m.e}</option>`).join("")}</select></div>
 <div class="field"><label>Жазба</label><textarea id="dtext" rows="7" placeholder="Ойларыңызды осында жазыңыз..."></textarea></div>
 <button class="btn" style="width:100%" onclick="saveDiary()">Сақтау</button></div></div>`)
}
function saveDiary(){
 const text=document.getElementById("dtext").value.trim();if(!text){toast("Жазба мәтінін енгізіңіз");return}
 state.diary.unshift({text,date:today(),mood:document.getElementById("dmood").value});save();closeModal();toast("Жазба сақталды");render()
}
function closeModal(){document.getElementById("modal")?.remove()}

function tests(){
 return `<div><div class="eyebrow">Тесттер</div><h1>Өзіңізді жақсырақ таныңыз</h1><p class="muted">Қысқа сауалнамалар өзін-өзі бақылауға көмектеседі.</p></div>
 <section class="grid" style="margin-top:18px;gap:12px">
 ${testCard("🪷","Стресс деңгейін бағалау","Күнделікті стресс белгілерін шамамен бағалау","stress",5)}
 ${testCard("🧠","Алаңдаушылық деңгейі","Соңғы күндердегі мазасыздық сезімдерін бақылау","anxiety",5)}
 ${testCard("💛","Эмоционалдық жағдай","Қазіргі эмоционалдық күйге қысқа шолу","emotion",5)}
 </section>`
}
function testCard(icon,title,desc,type,time){
 return `<div class="card test-card"><div class="test-icon">${icon}</div><div style="flex:1"><h3>${title}</h3><p class="small muted">${desc} · ${time} сұрақ</p></div><button class="btn secondary" onclick="runTest('${type}')">Бастау</button></div>`
}
const qs=[
 "Соңғы күндері өзіңізді жиі шаршаңқы сезіндіңіз бе?",
 "Күнделікті міндеттер сізге әдеттегіден ауыр көрінді ме?",
 "Демалуға уақыт табу қиын болды ма?",
 "Ойларыңызды тоқтатып, тынығу қиын болды ма?",
 "Өзіңізге уақыт бөлу жеткілікті болды ма?"
];
function runTest(type){
 let step=0,answers=[];
 document.body.insertAdjacentHTML("beforeend",`<div class="modal-back" id="modal"><div class="modal"><div class="row between"><div><div class="eyebrow">Өзін-өзі бағалау</div><h2 id="qtitle">Сұрақ 1 / 5</h2></div><button class="icon-btn" onclick="closeModal()">×</button></div><p id="qtext" style="font-size:18px;line-height:1.5">${qs[0]}</p><div id="opts" class="grid" style="gap:8px">${opts()}</div><p class="small muted">Нәтиже медициналық диагноз болып саналмайды.</p></div></div>`);
 window._test={type,step,answers};bindOpts()
}
function opts(){return ["Ешқашан","Сирек","Кейде","Жиі","Әрдайым"].map((x,i)=>`<button class="btn ${i===0?"ghost":"secondary"}" onclick="answerTest(${i+1})">${x}</button>`).join("")}
function bindOpts(){}
function answerTest(v){
 const t=window._test;t.answers.push(v);t.step++;
 if(t.step<qs.length){document.getElementById("qtitle").textContent=`Сұрақ ${t.step+1} / 5`;document.getElementById("qtext").textContent=qs[t.step];document.getElementById("opts").innerHTML=opts();return}
 const score=t.answers.reduce((a,b)=>a+b,0);
 state.tests.unshift({type:t.type,score,date:today()});state.tests=state.tests.slice(0,20);save();
 let level=score<=9?"төмен":score<=17?"орташа":"жоғары";
 document.getElementById("modal").innerHTML=`<div class="modal"><div class="eyebrow">Нәтиже</div><h2>Сіздің жалпы көрсеткішіңіз: ${score}/25</h2><div class="result"><b>Деңгей: ${level}</b><p class="small">Бұл қысқа өзін-өзі бағалау. Нәтижені диагноз немесе медициналық қорытынды ретінде қабылдамаңыз.</p></div><button class="btn" style="width:100%;margin-top:15px" onclick="closeModal();render()">Жабу</button></div>`
}

function more(){
 return `<div class="eyebrow">Көбірек</div><h1>Көмек және пайдалы кеңестер</h1>
 <section class="grid grid-2" style="margin-top:18px">
 <div class="card"><h2>Кеңестер</h2>${[
 ["🌿","Тыныс алу","4 секунд дем алыңыз, 4 секунд ұстап, 6 секунд баяу шығарыңыз."],
 ["🧘","Релаксация","Денеңіздің әр бөлігін кезекпен босаңсытып көріңіз."],
 ["💗","Өзіңізге қамқорлық","Ұйқы, тамақтану, қозғалыс және демалысқа назар аударыңыз."],
 ["🎯","Көңіл-күйді көтеру","Кішкентай жағымды әрекетті бүгін жоспарлап қойыңыз."]
 ].map(x=>`<div class="diary-item"><div class="row"><span style="font-size:25px">${x[0]}</span><div><b>${x[1]}</b><p class="small muted">${x[2]}</p></div></div></div>`).join("")}</div>
 <div class="card"><h2>Психолог</h2><div class="tip" style="padding:18px"><p>Егер сізге қиын болып жүрген жағдай туралы сөйлескіңіз келсе, сенімді ересек адамға немесе білікті маманға жүгінуге болады.</p></div>
 <button class="list-btn" onclick="contactInfo()">Маманмен байланысу <span>›</span></button>
 <button class="list-btn" onclick="showPrivacy()">Құпиялылық <span>›</span></button>
 <button class="list-btn" onclick="showSettings()">Баптаулар <span>›</span></button></div></section>
 <div class="footer-note">PsyBalance v1.0 · Деректер осы браузерде сақталады</div>`
}
function breathing(){
 document.body.insertAdjacentHTML("beforeend",`<div class="modal-back" id="modal"><div class="modal" style="text-align:center"><div class="eyebrow">2 минут</div><h2>Тыныс алу</h2><div id="breath" style="width:130px;height:130px;border-radius:50%;background:#e6f3ed;margin:25px auto;display:grid;place-items:center;font-size:18px;font-weight:700">Дайынсыз ба?</div><button class="btn" onclick="startBreath()">Бастау</button><button class="btn ghost" style="margin-left:8px" onclick="closeModal()">Жабу</button></div></div>`)
}
function startBreath(){
 let n=0;const el=document.getElementById("breath");const steps=["Дем алыңыз","Ұстап тұрыңыз","Баяу шығарыңыз"];el.textContent=steps[0];
 const timer=setInterval(()=>{n++;el.textContent=steps[n%3]},4000);setTimeout(()=>{clearInterval(timer);el.textContent="Жақсы жұмыс!";},24000)
}
function contactInfo(){toast("Бұл демо-нұсқада нақты маманға жазылу функциясы қосылмаған.")}
function showPrivacy(){alert("PsyBalance бұл нұсқада деректерді серверге жібермейді. Күнделік пен көңіл-күй белгілері браузердің localStorage жадында сақталады.")}
function showSettings(){
 document.body.insertAdjacentHTML("beforeend",`<div class="modal-back" id="modal"><div class="modal"><div class="row between"><h2>Баптаулар</h2><button class="icon-btn" onclick="closeModal()">×</button></div>
 <div class="field"><label>Есім</label><input id="setname" value="${esc(state.name)}"></div>
 <button class="btn" style="width:100%" onclick="saveSettings()">Сақтау</button>
 <button class="btn ghost" style="width:100%;margin-top:8px" onclick="resetApp()">Барлық деректі өшіру</button></div></div>`)
}
function saveSettings(){state.name=(document.getElementById("setname").value||"Аружан").trim();save();closeModal();render();toast("Баптаулар сақталды")}
function resetApp(){if(confirm("Барлық деректі өшіру керек пе?")){localStorage.removeItem(KEY);location.reload()}}
function go(p){current=p;render()}
render();
